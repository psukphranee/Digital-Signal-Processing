% LAB4-2024 Checks functionality of FIR window design
%      Place this file in same directory as your
%      rectfilt, hammingfilt and kaiserfilt functions.

%% Part 1: Check filter design

test_lab4a
%% Part II: Comparative behavior of window filters
test_lab4b

%% Part III: Phone tones
test_lab4c

