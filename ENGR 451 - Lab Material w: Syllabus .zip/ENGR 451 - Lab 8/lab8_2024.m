%% LAB 10 Spectral analyis lab
%       Copyright (c) 2021 Thomas Holton

%% Run tests
test_lab8_2024

%% Print program
disp(' ')
disp('--- dtmfdecode.m --------------------------------')
type('dtmfdecode')
