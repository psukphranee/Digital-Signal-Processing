function freq = index_to_freq(index, total_points, sampling_freq)
    
    freq = 2*pi*((index-1)/total_points);

end

